﻿namespace Players;

internal class MuseElf : Elf   // [ctrl] + [.]
{
    public MuseElf(string username, int level) : base(username, level)
    {
    }
}
