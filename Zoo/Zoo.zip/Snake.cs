﻿namespace Zoo;

internal class Snake : Reptile
{
    public Snake(string name) : base(name)
    {
    }
}
