﻿namespace Zoo;

internal class Lizard : Reptile
{
    public Lizard(string name) : base(name)
    {
    }
}
